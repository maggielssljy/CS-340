from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, mongo_user, mongo_pass, mongo_host, mongo_port, db, collection):
        """
        Initialize the MongoDB client and select the database and collection.
        """
        try:
            self.client = MongoClient(f'mongodb://{mongo_user}:{mongo_pass}@{mongo_host}:{mongo_port}')
            self.database = self.client[db]
            self.collection = self.database[collection]
            print("Connection to MongoDB successful!")
        except PyMongoError as e:
            print(f"[ERROR] Connection to MongoDB failed: {e}")
            self.client = None
            self.database = None
            self.collection = None

    def create(self, data):
        """
        Insert a document into the specified collection.
        :param data: A dictionary containing key/value pairs to insert.
        :return: True if successful insert, else False.
        """
        if data and isinstance(data, dict):
            try:
                result = self.collection.insert_one(data)
                print(f"Document inserted with ID: {result.inserted_id}")
                return bool(result.inserted_id)
            except PyMongoError as e:
                print(f"[ERROR] Insert failed: {e}")
                return False
        else:
            raise ValueError("Data must be a non-empty dictionary.")

    def read(self, query):
        """
        Query for documents in the specified collection.
        :param query: A dictionary with the lookup key/values.
        :return: A list of matching documents.
        """
        if query is not None and isinstance(query, dict):
            try:
                cursor = self.collection.find(query)
                result = list(cursor)
                print(f"Query returned {len(result)} documents.")
                return result
            except PyMongoError as e:
                print(f"[ERROR] Query failed: {e}")
                return []
        else:
            raise ValueError("Query must be a non-empty dictionary.")

    def update(self, query, new_values):
        """
        Update documents matching the query.
        :param query: A dictionary with keys/values to match.
        :param new_values: A dictionary with keys/values to update.
        :return: The number of documents updated.
        """
        if query and isinstance(query, dict) and new_values and isinstance(new_values, dict):
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                print(f"Updated {result.modified_count} document(s).")
                return result.modified_count
            except PyMongoError as e:
                print(f"[ERROR] Update failed: {e}")
                return 0
        else:
            raise ValueError("Query and update values must be non-empty dictionaries.")

    def delete(self, query):
        """
        Delete documents matching the query.
        :param query: A dictionary with keys/values to match for deletion.
        :return: The number of documents deleted.
        """
        if query and isinstance(query, dict):
            try:
                result = self.collection.delete_many(query)
                print(f"Deleted {result.deleted_count} document(s).")
                return result.deleted_count
            except PyMongoError as e:
                print(f"[ERROR] Delete failed: {e}")
                return 0
        else:
            raise ValueError("Query must be a non-empty dictionary.")
